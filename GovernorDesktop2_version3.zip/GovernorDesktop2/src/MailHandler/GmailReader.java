package MailHandler;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jatin
 */
import java.io.*;
import java.util.ArrayList;
import java.util.Properties;
import javax.mail.*;
import javax.mail.Flags.Flag;
import javax.mail.search.FlagTerm;

public class GmailReader {

    public static void saveFile(String filename, InputStream input) throws IOException {
        if (filename == null) {
            filename = File.createTempFile("MailAttacheFile", ".out").getName();
        }
        System.out.println("downloading attachment...");
        File file = new File(filename);
        for (int i = 0; file.exists(); i++) {
            file = new File(filename + i);
        }
        FileOutputStream fos = new FileOutputStream(file);
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        BufferedInputStream bis = new BufferedInputStream(input);
        int fByte;
        while ((fByte = bis.read()) != -1) {
            bos.write(fByte);
        }
        bos.flush();
        bos.close();
        bis.close();
        System.out.println("done attachment...");
    }

    public static void handlePart(Part part) throws MessagingException, IOException {
        String dposition = part.getDisposition();
        String cType = part.getContentType();
        if (dposition == null) {
            System.out.println("Null: " + cType);
            if ((cType.length() >= 10) && (cType.toLowerCase().substring(0, 10).equals("text/plain"))) {
                part.writeTo(System.out);
            } else {
                System.out.println("Other body: " + cType);
                part.writeTo(System.out);
            }
        } else if (dposition.equalsIgnoreCase(Part.ATTACHMENT)) {
            System.out.println("Attachment: " + part.getFileName() + " : " + cType);
            //         saveFile(part.getFileName(), part.getInputStream());
        } else if (dposition.equalsIgnoreCase(Part.INLINE)) {
            System.out.println("Inline: " + part.getFileName() + " : " + cType);
            //       saveFile(part.getFileName(), part.getInputStream());
        } else {
            System.out.println("Other: " + dposition);
        }
    }

    public ArrayList<Message> getMessages() throws Exception {
       /* String host = "pop.gmail.com";
        String username = "mt2011.project5c"; //Put here Gmail Username without @ sign
        String password = "mt2011p5c"; // put here Gmail password
        Session session = Session.getInstance(new Properties(), null);
        Store store = session.getStore("pop3s");
        store.connect(host, username, password);
        Folder folder = store.getFolder("INBOX");
        folder.open(Folder.READ_ONLY);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Message message[] = folder.getMessages();
        Message newMessage[]=folder.getMessages();
        int count = 0;
        for (int i = 0; i < message.length; i++) {

            if(!message[i].isSet(Flag.SEEN)){
                System.out.println(message[i].isSet(Flag.SEEN));
                message[i].setFlag(Flag.SEEN, true);
                 System.out.println(message[i].isSet(Flag.SEEN));
                newMessage[count]=message[i];
                count++;
            }
        }
        return newMessage;*/
        /*try {
            Enumeration headers = message[0].getAllHeaders();
            while (headers.hasMoreElements()) {
                Header h = (Header) headers.nextElement();
                System.out.println(h.getName() + ": " + h.getValue());
            }
        } catch (Exception ext) {
            System.out.println("\nNo new messages");

        }


        for (int i = 0; i < message.length; i++) {
            System.out.println(i + ": " + message[i].getFrom()[0] + "\t" + message[i].getSubject());
            System.out.println("Want to get the content? [Y to read/Q to end]");
            String ans = reader.readLine();
            ans = ans.toLowerCase();
            if ("y".equals(ans)) {
                Object content = message[i].getContent();
                if (content instanceof Multipart) {
                    handleMultipart((Multipart) content);
                } else {
                    handlePart(message[i]);
                }
            }
            else if ("q".equals(ans)) {
            break;
            }
        }*/
        String host = "imap.gmail.com";
        String username = "mt2011.project5c"; //Put here Gmail Username without @ sign
        String password = "mt2011p5c"; // put here Gmail password
        Session session = Session.getInstance(new Properties(), null);
        Store store = session.getStore("imaps");
        store.connect(host, username, password);
        Folder folder = store.getFolder("INBOX");
        folder.open(Folder.READ_WRITE);
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        FlagTerm ft = new FlagTerm(new Flags(Flags.Flag.SEEN), false);
        Message message[] = folder.search(ft);
        ArrayList<Message> newMessage = new ArrayList<Message>();
        for (int i = 0; i < message.length; i++) {
                            
            if((!message[i].isSet(Flag.SEEN))&&(message[i].getFrom()[0].toString().equals("mt2011 project5c <project5c.admn@gmail.com>"))){
                
               // System.out.println(message[i].isSet(Flag.SEEN));
                newMessage.add(message[i]);
                message[i].setFlag(Flag.SEEN, true);
                // System.out.println(message[i].isSet(Flag.SEEN));

            }
 else{
         //  System.out.println(message[i].getFrom()[0]);
 }
        }
        /*Message message[] = folder.getMessages();
        Message newMessage[]=folder.getMessages();
        int count = 0;
        for (int i = 0; i < message.length; i++) {

            if(!message[i].isSet(Flag.SEEN)){
                System.out.println(message[i].isSet(Flag.SEEN));
                message[i].setFlag(Flag.SEEN, true);
                 System.out.println(message[i].isSet(Flag.SEEN));
                newMessage[count]=message[i];
                count++;
            }
        }*/
        return newMessage;
    }

    public static void handleMultipart(Multipart multipart) throws MessagingException, IOException {
        for (int i = 0; i < (multipart.getCount()); i++) {
            handlePart(multipart.getBodyPart(i));
        }
    }
}
