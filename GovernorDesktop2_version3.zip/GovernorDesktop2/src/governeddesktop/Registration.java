package governeddesktop;

import NetworkCommManager.RmiClient;

import java.rmi.registry.*;
import java.net.*;

public class Registration
{
    String thisPort;
    
   String thisAddress;
   String myname;
   String myip;
   Registry registry;
    String myretVal;
    RmiClient rmiclient;

        void setParameters()
        {
            try{
            rmiclient = new RmiClient();
            thisAddress= (InetAddress.getLocalHost()).toString();
            thisPort="9595";

            System.out.println("this address="+thisAddress+",port="+thisPort);
            myname=thisAddress.substring(thisAddress.indexOf(""),thisAddress.indexOf("/"));
            myip=thisAddress.substring(thisAddress.indexOf("/")+1);
            System.out.println("IP address : "+myip);
            System.out.println("Host Name: "+myname);
            }catch(Exception e)
            {}

        }
         void registerRequest()
        {
            setParameters();
            rmiclient.registerRemoteSystem(myip,thisPort,myname);
 
        }

         void deRegisterRequest()
        {
            setParameters();
            rmiclient.deRegisterRemoteSystem(myip,thisPort,myname);

        }
  
 }
  