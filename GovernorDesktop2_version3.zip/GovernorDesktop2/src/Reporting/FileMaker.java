/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Reporting;
import java.io.*;
import java.io.FileWriter;
/**
 *
 * @author root
 */
public class FileMaker {
 public void prepareFile(String fileName, String text, boolean append) {

        File file = new File(fileName);
        try{
            boolean exist = file.createNewFile();
            BufferedWriter out = new BufferedWriter(new FileWriter(file,append));
            out.write(text);
            out.close();
            System.out.println("File created successfully.");
        
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
