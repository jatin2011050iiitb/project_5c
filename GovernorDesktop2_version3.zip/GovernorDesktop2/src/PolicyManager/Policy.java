/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package PolicyManager;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author jatin_c
 */
public class Policy implements Serializable {

    private String ipAddress;
    private String portNo;
    private String name;
    private ArrayList<PolicyItem> policyItems;

    /**
     * @return the ipAddress
     */
    public String getIpAddress() {
        return ipAddress;
    }

    /**
     * @param ipAddress the ipAddress to set
     */
    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    /**
     * @return the portNo
     */
    public String getPortNo() {
        return portNo;
    }

    /**
     * @param portNo the portNo to set
     */
    public void setPortNo(String portNo) {
        this.portNo = portNo;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the policyItems
     */
    public ArrayList<PolicyItem> getPolicyItems() {
        return policyItems;
    }

    /**
     * @param policyItems the policyItems to set
     */
    public void setPolicyItems(ArrayList<PolicyItem> policyItems) {
        this.policyItems = policyItems;
    }



    public static Policy policyFileReader(String fileName){

        Policy p = new Policy();
        p.setIpAddress(null);
        p.setName(null);
        p.setPortNo(null);
        p.setPolicyItems(null);
        FileInputStream fis = null;
        ObjectInputStream in = null;

        try{

            fis = new FileInputStream(fileName);
            in = new ObjectInputStream(fis);
            p = (Policy)in.readObject();
        }catch(Exception ex){

            ex.printStackTrace();
        }

        return p;

    }
}
