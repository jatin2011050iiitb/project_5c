/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ProcessMonitor;

import NetworkCommManager.RmiClient;
import Reporting.Report;
import governordesktop2.DataFrame;
import java.awt.Color;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;



public class AutoMonitoringThread implements Runnable{

    String regName;
    String serverIP;
    String serverPort;
    RmiClient rmiclient;
    public static boolean finishAll = false;
    public static int countAutoMonitThreads;
    String retVal;
    Thread t;
    int time;
    int index;

    public AutoMonitoringThread(){}
    public AutoMonitoringThread(String regNameParam,String serverIPParam, String serverPortParam,int indexParam)
    {
      regName = regNameParam;
      serverIP = serverIPParam;
      serverPort = serverPortParam;
      index = indexParam;
      rmiclient = new RmiClient();
      retVal = "DEFAULT";
      t = new Thread(this, regName);
      time = 2000;
      countAutoMonitThreads++;
      t.start();
    }
    public void run()
    {
        try {
            while(!finishAll)
            {
                System.out.println("Thread : "+regName+":"+serverIP+":"+serverPort);
                try {
                    retVal = rmiclient.sendRequest(regName, serverIP, serverPort, "top -b -n1");
                } catch (Exception ex)
                {
                    DataFrame.jb[index].setForeground(Color.red);
                    DataFrame.jb[index].setText("RED");
                    System.out.println("Error");
                }
                if(!retVal.equals("DEFAULT"))
                {
                    Report rt = new Report();
                    rt.createMonitoringFile(retVal, regName+"Proc.txt");
                    ArrayList <ProcFileEntry> entries = ProcessMonitor.readProcFileInfo(regName+"Proc.txt");
                    ArrayList <ProcFileEntry> killEntries = new ArrayList <ProcFileEntry>();

                    for(ProcFileEntry e : entries)
                    {
                        if(Integer.parseInt(e.CPU) > 2)
                            killEntries.add(e);
                    }

                    for(ProcFileEntry e : killEntries)
                    {
                        System.out.println(e.PID);
                    }
              }
                retVal = "DEFAULT";
                Thread.sleep(time);
            }
            System.out.println("Thread Stopped: "+regName+":"+serverIP+":"+serverPort);

        } catch (InterruptedException ex) {
            Logger.getLogger(AutoMonitoringThread.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
