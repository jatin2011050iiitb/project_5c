package ProcessMonitor;

public class ProcFileEntry {

    public String PID;
    public String USER;
    public String PR;
    public String NI;
    public String VIRT;
    public String RES;
    public String SHR;
    public String S;
    public String CPU;
    public String MEM;
    public String TIME;
    public String COMMAND;
}
