package NetworkCommManager;

import java.rmi.*;

public interface ReceiveMessageInterface extends Remote
{
    String receiveMessage(String x) throws RemoteException;
    String registerRemoteSystem(String regString) throws RemoteException;
    String deRegisterRemoteSystem(String regString) throws RemoteException;

}