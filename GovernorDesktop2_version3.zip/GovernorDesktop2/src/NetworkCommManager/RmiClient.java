package NetworkCommManager;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectOutputStream;
import java.rmi.*;
//import java.rmi.RMISecurityManager;
import java.rmi.registry.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RmiClient
{
    String retVal = "DEFAULT";
    private String serverAddress;
    private String serverPort;
    private String request;

    public String registerRemoteSystem(String serverIP, String port,String regName)
    {
        try{
            ReceiveMessageInterface rmiServer;
            Registry registry;
            System.setSecurityManager(new java.rmi.RMISecurityManager());
            String serverAddress ="192.168.11.37";//InetAddress.getLocalHost().getHostAddress();
            String serverPort = "18888";
            registry = LocateRegistry.getRegistry(serverAddress, (new Integer(serverPort)).intValue());
            // look up the remote object
            rmiServer = (ReceiveMessageInterface) (registry.lookup("Governor"));
            // call the remote method
            String regString =regName + ":" +serverIP+ ":" +port;
            System.out.println("This is:"+regString);
            retVal = rmiServer.registerRemoteSystem(regString);
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        return retVal;
    }

    public String deRegisterRemoteSystem(String serverIP, String port,String regName)
    {
        try{
            ReceiveMessageInterface rmiServer;
            Registry registry;
            System.setSecurityManager(new java.rmi.RMISecurityManager());
            String serverAddress ="192.168.11.37";//InetAddress.getLocalHost().getHostAddress();
            String serverPort = "18888";
            registry = LocateRegistry.getRegistry(serverAddress, (new Integer(serverPort)).intValue());
            // look up the remote object
            rmiServer = (ReceiveMessageInterface) (registry.lookup("Governor"));
            // call the remote method
            String regString =regName + ":" +serverIP+ ":" +port;
            System.out.println("This is:"+regString);
            retVal = rmiServer.registerRemoteSystem(regString);
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        return retVal;
    }

    /*public String sendRequest(String serverIP, String port,String command)
        {
        try{
            ReceiveMessageInterface rmiServer;
            Registry registry;
            System.setSecurityManager(new java.rmi.RMISecurityManager());
            String serverAddress =serverIP;//InetAddress.getLocalHost().getHostAddress();
            String serverPort = port;

            //String path = "/home/monika/second_semester/OS/osproject/RMI1/";
            //Creates a stub for remote object registry
            registry = LocateRegistry.getRegistry(serverAddress, (new Integer(serverPort)).intValue());
            // look up the remote object
            rmiServer = (ReceiveMessageInterface) (registry.lookup("rmiServer"));
            // call the remote method
            System.out.println("sending 3" + command + " to " + serverAddress + ":" + serverPort);
            retVal = rmiServer.receiveMessage(command);
            System.out.println("Command Executed");
            //return retVal;

            }
            catch (Exception ex)
            {
                System.out.println(ex.getMessage());
            }

            return retVal;

        }*/

    public String sendRequest(String regName, String serverIP, String port,String command) throws Exception
        {
        
            ReceiveMessageInterface rmiServer;
            Registry registry;
            System.setSecurityManager(new java.rmi.RMISecurityManager());
            String serverAddress =serverIP;//InetAddress.getLocalHost().getHostAddress();
            String serverPort = port;

            //String path = "/home/monika/second_semester/OS/osproject/RMI1/";
            //Creates a stub for remote object registry
            registry = LocateRegistry.getRegistry(serverAddress, (new Integer(serverPort)).intValue());
            // look up the remote object
            rmiServer = (ReceiveMessageInterface) (registry.lookup(regName));
            // call the remote method
            System.out.println("sending 3" + command + " to " + serverAddress + ":" + serverPort);
            retVal = rmiServer.receiveMessage(command);
            System.out.println("Command Executed : "+retVal);
            //return retVal;

            return retVal;

        }

    public String executeRequest()
    {

        try {
            ReceiveMessageInterface rmiServer;
            Registry registry;
            System.setSecurityManager(new java.rmi.RMISecurityManager());
            registry = LocateRegistry.getRegistry(serverAddress, (new Integer(serverPort)).intValue());
            rmiServer = (ReceiveMessageInterface) (registry.lookup("rmiServer"));
            return rmiServer.receiveMessage(getRequest());
        }
        catch (NotBoundException ex) {
            Logger.getLogger(RmiClient.class.getName()).log(Level.SEVERE, null, ex);
        } catch (AccessException ex) {
            Logger.getLogger(RmiClient.class.getName()).log(Level.SEVERE, null, ex);
        }        catch (RemoteException ex) {
            Logger.getLogger(RmiClient.class.getName()).log(Level.SEVERE, null, ex);
        }

       return "No result for:"+getRequest();

    }

    public String getServerAddress() {
        return serverAddress;
    }

    public void setServerAddress(String serverAddress) {
        this.serverAddress = serverAddress;
    }

    public String getServerPort() {
        return serverPort;
    }

    public void setServerPort(String serverPort) {
        this.serverPort = serverPort;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }
}