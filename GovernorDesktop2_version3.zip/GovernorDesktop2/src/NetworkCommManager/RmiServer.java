package NetworkCommManager;

import ProcessMonitor.AutoMonitoringThread;
import Reporting.Report;
import java.io.*;
import java.rmi.*;
import java.rmi.registry.*;
import governordesktop2.DataFrame;
import governordesktop2.PracticeApp1;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RmiServer extends java.rmi.server.UnicastRemoteObject
implements ReceiveMessageInterface
{
    int      thisPort;
   String   thisAddress;
    Registry registry;
     String results = null;// rmi registry for lookup the remote objects.
     AutoMonitoringThread mt = null;

    // This method is called from the remote client by the RMI.
    // This is the implementation of the ï¿½gReceiveMessageInterfaceï¿½h.

     public String registerRemoteSystem(String regString) throws RemoteException
     {
        Report newReport = new Report();
        newReport.addToFile(regString+"\n", "registration.txt");
        String arr[] = regString.split(":");

        if(governordesktop2.MainWindow.autoMonitStatus)
        {
            //mt = new AutoMonitoringThread(arr[0],arr[1],arr[2],AutoMonitoringThread.countAutoMonitThreads+1);
            //DataFrame.loadDynField(arr[0], arr[1],arr[2]);
            PracticeApp1.disposeWindow();
            PracticeApp1.createWindow();
         }
        System.out.println("Remote System Registered");
        return "SUCCESS";
     }

     public String deRegisterRemoteSystem(String regString) throws RemoteException
     {
        Report newReport = new Report();
        newReport.removeFromFile(regString, "registration.txt");
        System.out.println("Remote System De-registered");
        return "SUCCESS";
     }
     
    public String receiveMessage(String x) throws RemoteException
    {
        try {
            //System.out.println(x);
            //Process myprocess = Runtime.getRuntime().exec("sh /home/monika/second_semester/OS/osproject/RMI1/param");
            Process  process = Runtime.getRuntime().exec(x);

            //File f = new File("")
           

            InputStream is = process.getInputStream();
            StringBuffer bfstr = new StringBuffer();
            int ch=0;

            while ((ch=is.read()) != -1)
            bfstr.append((char)ch);

            results = new String(bfstr.toString());
            is.close();

            //Process  process1 = Runtime.getRuntime().exec("1>/home/monika/second_semester/OS/osproject/RMI1/echoFile");
            System.out.println(results);

        } catch (IOException ex) {
            Logger.getLogger(RmiServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return results;
    }

    public RmiServer() throws RemoteException
    {
        super();
        try
        {
            // get the address of this host.
            thisAddress= (InetAddress.getLocalHost()).toString();
        }
        catch(Exception e){
            throw new RemoteException("can't get inet address.");
        }
        thisPort=9595;  // this port(registryï¿½fs port
        System.out.println("this address="+thisAddress+",port="+thisPort);
        try{
        // create the registry and bind the name and object.
        registry = LocateRegistry.createRegistry( thisPort );

        try{
        registry.rebind((InetAddress.getLocalHost()).toString().substring(thisAddress.indexOf(""),thisAddress.indexOf("/")), this);
            }
        catch(Exception exc){
            System.out.println("Exception occured in rebind");
        }
        }
        catch(RemoteException e){throw e;}

    }

    static public void startGovernorServer()
    {
            try{
        RmiServer s=new RmiServer();
        System.out.println("RmiServer started");
    }
    catch (Exception e)
    {
           e.printStackTrace();
    }
    }

    /*static public void main(String args[])
    {
        try{
        RmiServer s=new RmiServer();
    }
    catch (Exception e) {
           e.printStackTrace();
           System.exit(1);
    }

     }*/

}

