

package governordesktop2;

import ProcessMonitor.AutoMonitoringThread;
import ProcessMonitor.Entry;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class DataFrame extends JFrame
{

    static JLabel dynLabel[];
    public static JButton jb[];
    static AutoMonitoringThread[] mt;
    static int row = 0;
    static int index = 0;
    static int textBaseX = 100;
    static int textBaseY = 100;
    static Container panel;

    DataFrame(ArrayList <Entry> entries)
    {
        mt = new AutoMonitoringThread[entries.size()];
        dynLabel = new JLabel[entries.size()*3];
        jb = new JButton[entries.size()];

        this.setSize(1000, 1000);
        //this.setTitle("Window-1");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = this.getContentPane();
        panel.setLayout(null);

        int i = 0;
        //int j = 0;

        for(Entry e : entries)
        {
            
            System.out.println(e.getRegName()+":"+e.getServerIP()+":"+e.getServerPort());
            loadDynField(e.getRegName(),e.getServerIP(),e.getServerPort());
        }


    }


        public static void loadDynField(String regNameParam,String serverIPParam, String serverPortParam)
        {
                int i = 0;
                int x = 0;
                 for(i = row*3;i<(row*3 + 3);i++)
                {

                    dynLabel[i] = new JLabel();
                    dynLabel[i].setLocation((textBaseX + x*100),(textBaseY + row*20));
                    dynLabel[i].setSize(200, 20);
                    panel.add(dynLabel[i]);
                    
                    if(i%3 == 0)
                        dynLabel[i].setText(regNameParam);
                    else if(i%3 == 1)
                        dynLabel[i].setText(serverIPParam);
                    else if(i%3 == 2)
                        dynLabel[i].setText(serverPortParam);

                    x++;
                }

                jb[row] = new JButton();
                jb[row].setLocation((textBaseX + x*100), textBaseY + row*20);
                jb[row].setSize(100, 20);
                jb[row].addActionListener(new ButtonHandler(row));
                jb[row].setForeground(Color.green);
                jb[row].setText("GREEN");
                panel.add(jb[row]);

                textBaseY = textBaseY + 30;
                row++;

                
                mt[index] = new AutoMonitoringThread(regNameParam,serverIPParam,serverPortParam,index);
                index++;
                
        }
    }


    class ButtonHandler implements ActionListener
    {


        ButtonHandler(int j)
        {

        }

        public void actionPerformed(ActionEvent e)
        {

        }


    }

