
package governordesktop2;

import javax.swing.JFrame;

public class MonitoringWindow extends javax.swing.JFrame {

    int flag = 0;
    Multithreading mt1;
    String serverIP, port,regName;

    /** Default constructor : Creates new form MonitoringWindow */
    public MonitoringWindow() {}

    /** Creates new form MonitoringWindow */
    public MonitoringWindow(String regNameCalled,String serverIPCalled, String portCalled) {
        serverIP = serverIPCalled;
        port = portCalled;
        regName = regNameCalled;
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        MainTabbedPane = new javax.swing.JTabbedPane();
        InfoTabbedPane = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        SITextArea = new javax.swing.JTextArea();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        UITextArea = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        CPUTabbedPane = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        AITextArea = new javax.swing.JTextArea();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        CITextArea = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        ProcessTabbedPane = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        LPTextArea = new javax.swing.JTextArea();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        PTTextArea = new javax.swing.JTextArea();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        FSTextArea = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        MainTabbedPane.setAutoscrolls(true);
        MainTabbedPane.setMaximumSize(getMaximumSize());
        MainTabbedPane.setMinimumSize(getMinimumSize());
        MainTabbedPane.setPreferredSize(getMaximumSize());
        MainTabbedPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MainTabbedPaneMouseClicked(evt);
            }
        });

        InfoTabbedPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                InfoTabbedPaneMouseClicked(evt);
            }
        });

        SITextArea.setColumns(20);
        SITextArea.setRows(5);
        jScrollPane3.setViewportView(SITextArea);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
        );

        InfoTabbedPane.addTab("System Information", jPanel1);

        UITextArea.setColumns(20);
        UITextArea.setRows(5);
        jScrollPane4.setViewportView(UITextArea);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
        );

        InfoTabbedPane.addTab("User Information", jPanel8);

        MainTabbedPane.addTab("General Information", InfoTabbedPane);

        CPUTabbedPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CPUTabbedPaneMouseClicked(evt);
            }
        });

        AITextArea.setColumns(20);
        AITextArea.setRows(5);
        jScrollPane5.setViewportView(AITextArea);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
        );

        CPUTabbedPane.addTab("CPU Architecture", jPanel3);

        CITextArea.setColumns(20);
        CITextArea.setRows(5);
        jScrollPane6.setViewportView(CITextArea);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
        );

        CPUTabbedPane.addTab("Core Details", jPanel9);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(CPUTabbedPane, javax.swing.GroupLayout.DEFAULT_SIZE, 370, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(CPUTabbedPane, javax.swing.GroupLayout.DEFAULT_SIZE, 253, Short.MAX_VALUE)
        );

        MainTabbedPane.addTab("CPU", jPanel2);

        ProcessTabbedPane.setAutoscrolls(true);
        ProcessTabbedPane.setMaximumSize(ProcessTabbedPane.getMaximumSize());
        ProcessTabbedPane.setMinimumSize(ProcessTabbedPane.getMinimumSize());
        ProcessTabbedPane.setPreferredSize(ProcessTabbedPane.getMaximumSize());
        ProcessTabbedPane.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ProcessTabbedPaneMouseClicked(evt);
            }
        });

        LPTextArea.setColumns(20);
        LPTextArea.setRows(5);
        jScrollPane1.setViewportView(LPTextArea);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
        );

        ProcessTabbedPane.addTab("List of Processes", jPanel5);

        PTTextArea.setColumns(20);
        PTTextArea.setRows(5);
        jScrollPane2.setViewportView(PTTextArea);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 365, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
        );

        ProcessTabbedPane.addTab("Process Tree", jPanel6);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ProcessTabbedPane, javax.swing.GroupLayout.DEFAULT_SIZE, 370, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(ProcessTabbedPane, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 253, Short.MAX_VALUE)
        );

        MainTabbedPane.addTab("Process", jPanel4);

        FSTextArea.setColumns(20);
        FSTextArea.setRows(5);
        jScrollPane7.setViewportView(FSTextArea);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 370, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 253, Short.MAX_VALUE)
        );

        MainTabbedPane.addTab("File System", jPanel7);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(MainTabbedPane, javax.swing.GroupLayout.DEFAULT_SIZE, 375, Short.MAX_VALUE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(MainTabbedPane, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ProcessTabbedPaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ProcessTabbedPaneMouseClicked
        // TODO add your handling code here:
        if(flag == 1)
                mt1.finish = true;

        if(ProcessTabbedPane.getSelectedIndex() == 0)
        {
             String tName = "LP"+":"+regName+":"+serverIP+":"+port;
             mt1 = new Multithreading(tName,this);
             flag = 1;
         }
        else if(ProcessTabbedPane.getSelectedIndex() == 1)
        {
            String tName = "PT"+":"+regName+":"+serverIP+":"+port;
            mt1 = new Multithreading(tName,this);
            flag = 1;
        }
    }//GEN-LAST:event_ProcessTabbedPaneMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
        String tName = "SI"+":"+regName+":"+serverIP+":"+port;
        mt1 = new Multithreading(tName,this);
        flag = 1;
    }//GEN-LAST:event_formWindowOpened

    private void MainTabbedPaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MainTabbedPaneMouseClicked
        // TODO add your handling code here:
        if(flag == 1)
                mt1.finish = true;

        if(MainTabbedPane.getSelectedIndex() == 0)
        {
           InfoTabbedPane.setSelectedIndex(0);
           String tName = "SI"+":"+regName+":"+serverIP+":"+port;
           mt1 = new Multithreading(tName,this);
           flag = 1; 
        }
        else if(MainTabbedPane.getSelectedIndex() == 1)
        {
           CPUTabbedPane.setSelectedIndex(0);
           String tName = "AI"+":"+regName+":"+serverIP+":"+port;
           mt1 = new Multithreading(tName,this);
           flag = 1;
        }
        else if(MainTabbedPane.getSelectedIndex() == 2)
        {
           ProcessTabbedPane.setSelectedIndex(0);
           String tName = "LP"+":"+regName+":"+serverIP+":"+port;
           mt1 = new Multithreading(tName,this);
           flag = 1;
        }
        else if(MainTabbedPane.getSelectedIndex() == 3)
        {
           String tName = "FS"+":"+regName+":"+serverIP+":"+port;
           mt1 = new Multithreading(tName,this);
           flag = 1;
        }
    }//GEN-LAST:event_MainTabbedPaneMouseClicked

    private void InfoTabbedPaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_InfoTabbedPaneMouseClicked
        // TODO add your handling code here:
        if(flag == 1)
                mt1.finish = true;

        if(InfoTabbedPane.getSelectedIndex() == 0)
        {
             String tName = "SI"+":"+regName+":"+serverIP+":"+port;
             mt1 = new Multithreading(tName,this);
             flag = 1;
         }
        else if(InfoTabbedPane.getSelectedIndex() == 1)
        {
            String tName = "UI"+":"+regName+":"+serverIP+":"+port;
            mt1 = new Multithreading(tName,this);
            flag = 1;
        }
    }//GEN-LAST:event_InfoTabbedPaneMouseClicked

    private void CPUTabbedPaneMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CPUTabbedPaneMouseClicked
        // TODO add your handling code here:
        if(flag == 1)
                mt1.finish = true;

        if(CPUTabbedPane.getSelectedIndex() == 0)
        {
             String tName = "AI"+":"+regName+":"+serverIP+":"+port;
             mt1 = new Multithreading(tName,this);
             flag = 1;
         }
        else if(CPUTabbedPane.getSelectedIndex() == 1)
        {
            String tName = "CI"+":"+regName+":"+serverIP+":"+port;
            mt1 = new Multithreading(tName,this);
            flag = 1;
        }
    }//GEN-LAST:event_CPUTabbedPaneMouseClicked

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        // TODO add your handling code here:
        mt1.finish = true;
    }//GEN-LAST:event_formWindowClosed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:
    }//GEN-LAST:event_formWindowClosing

    public void printCommandOutput(String param, String textAreaID)
    {
        if(textAreaID.equalsIgnoreCase("SI"))
        {
            SITextArea.setText(param);
        }
        else if(textAreaID.equalsIgnoreCase("UI"))
        {
            UITextArea.setText(param);
        }

        else if(textAreaID.equalsIgnoreCase("AI"))
        {
            AITextArea.setText(param);
        }

        else if(textAreaID.equalsIgnoreCase("CI"))
        {
            CITextArea.setText(param);
        }

        else if(textAreaID.equalsIgnoreCase("LP"))
        {
            LPTextArea.setText(param);
        }
        else if(textAreaID.equalsIgnoreCase("PT"))
        {
            PTTextArea.setText(param);
        }
        else if(textAreaID.equalsIgnoreCase("FS"))
        {
            FSTextArea.setText(param);
        }
     }
    public void displayMonitoring(final String regName, final String serverIP,final String port)
    {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run()
            {
                MonitoringWindow mw = new MonitoringWindow(regName,serverIP,port);
                mw.setVisible(true);
               mw.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AITextArea;
    private javax.swing.JTextArea CITextArea;
    private javax.swing.JTabbedPane CPUTabbedPane;
    private javax.swing.JTextArea FSTextArea;
    private javax.swing.JTabbedPane InfoTabbedPane;
    private javax.swing.JTextArea LPTextArea;
    private javax.swing.JTabbedPane MainTabbedPane;
    private javax.swing.JTextArea PTTextArea;
    private javax.swing.JTabbedPane ProcessTabbedPane;
    private javax.swing.JTextArea SITextArea;
    private javax.swing.JTextArea UITextArea;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    // End of variables declaration//GEN-END:variables

}
