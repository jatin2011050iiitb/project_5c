package governordesktop2;

import ProcessMonitor.AutoMonitoringThread;
import ProcessMonitor.Entry;
import ProcessMonitor.ProcessMonitor;
import java.util.ArrayList;
import javax.swing.JFrame;


public class PracticeApp1 {
    static DataFrame df;

    public static void createWindow()
    {
        ArrayList <Entry> entries;
        ProcessMonitor pm = new ProcessMonitor();
        entries = pm.readRegisteredSystemInfo();
        System.out.println("Number of Entries = "+entries.size());

        df = new DataFrame(entries);
        df.setVisible(true);
        df.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    public static void disposeWindow()
    {
        AutoMonitoringThread.finishAll = true;
        df.dispose();
    }

    public static void main(String[] args) {

        //new DataFrame().setVisible(true);
        createWindow();

    }

}
