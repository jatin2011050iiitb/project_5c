package ModuleOrchastrator;

import NetworkCommManager.*;

public class GovernorOrchastrator {

    public String monitorPerformanceParam(String regName,String serverIP, String port) throws Exception
    {
        RmiClient client = new RmiClient();
        return client.sendRequest(regName,serverIP, port,"sh param");
    }

    public String monitorSystemInfo(String regName,String serverIP, String port) throws Exception
    {
        RmiClient client = new RmiClient();
        return client.sendRequest(regName,serverIP, port,"uname -a");
    }

    public String monitorUserInfo(String regName,String serverIP, String port) throws Exception
    {
        RmiClient client = new RmiClient();
        return client.sendRequest(regName,serverIP, port,"w");
    }

    public String monitorArchitectureInfo(String regName,String serverIP, String port) throws Exception
    {
        RmiClient client = new RmiClient();
        return client.sendRequest(regName,serverIP, port,"lscpu");
    }

    public String monitorCoreInfo(String regName,String serverIP, String port) throws Exception
    {
        RmiClient client = new RmiClient();
        return client.sendRequest(regName,serverIP, port,"mpstat -P ALL");
    }


    public String monitorProcesses(String regName,String serverIP, String port) throws Exception
    {
        RmiClient client = new RmiClient();
        return client.sendRequest(regName,serverIP, port,"top -b -n1");

    }

    public String monitorProcessTree(String regName,String serverIP, String port) throws Exception
    {
        RmiClient client = new RmiClient();
        return client.sendRequest(regName,serverIP, port,"pstree");
    }
    public String monitorFileSystem(String regName,String serverIP, String port) throws Exception
    {
        RmiClient client = new RmiClient();
        return client.sendRequest(regName,serverIP, port,"df -ahT");
    }
}
